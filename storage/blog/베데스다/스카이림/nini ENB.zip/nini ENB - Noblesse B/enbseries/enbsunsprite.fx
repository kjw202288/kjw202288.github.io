//++++++++++++++++++++++++++++++++++++++++++++++++
// Multiple Lens Sun Sprite Shader by Phinix
// http://www.nexusmods.com/skyrim/mods/24235/
//++++++++++++++++++++++++++++++++++++++++++++++++
// ENBSeries effect file
// visit http://enbdev.com for updates
// Copyright (c) 2007-2013 Boris Vorontsov
//++++++++++++++++++++++++++++++++++++++++++++++++

//++++++++++++++++++++++++++++++++++++++++++++++++
//internal parameters, can be modified
//++++++++++++++++++++++++++++++++++++++++++++++++

	float ELenzIntensity <
		string UIName="Sun Sprite Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.9};

	float ELenzScale <
		string UIName="Sun Sprite Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=10.0;
	> = {0.86};

	float ECloudBlend <
		string UIName="Sun Sprite Blend";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {1.45};

//++++++++++++++++++++++++++++++++++++++++++++++++
//separate lens control: offset, scale
//++++++++++++++++++++++++++++++++++++++++++++++++

//Lens0
	float L0Offset <
		string UIName="L0Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.29};
	float L0Scale <
		string UIName="L0Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.79};
	float L0Intensity <
		string UIName="L0Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens1
	float L1Offset <
		string UIName="L1Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.38};
	float L1Scale <
		string UIName="L1Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.95};
	float L1Intensity <
		string UIName="L1Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens2
	float L2Offset <
		string UIName="L2Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.47};
	float L2Scale <
		string UIName="L2Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.48};
	float L2Intensity <
		string UIName="L2Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens3
	float L3Offset <
		string UIName="L3Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.8};
	float L3Scale <
		string UIName="L3Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.91};
	float L3Intensity <
		string UIName="L3Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens4
	float L4Offset <
		string UIName="L4Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.84};
	float L4Scale <
		string UIName="L4Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.0};
	float L4Intensity <
		string UIName="L4Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.64};

//Lens5
	float L5Offset <
		string UIName="L5Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.89};
	float L5Scale <
		string UIName="L5Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {2.3};
	float L5Intensity <
		string UIName="L5Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens6
	float L6Offset <
		string UIName="L6Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.94};
	float L6Scale <
		string UIName="L6Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {2.84};
	float L6Intensity <
		string UIName="L6Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens7
	float L7Offset <
		string UIName="L7Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.99};
	float L7Scale <
		string UIName="L7Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {2.3};
	float L7Intensity <
		string UIName="L7Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens8
	float L8Offset <
		string UIName="L8Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {1.07};
	float L8Scale <
		string UIName="L8Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.33};
	float L8Intensity <
		string UIName="L8Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens9
	float L9Offset <
		string UIName="L9Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.97};
	float L9Scale <
		string UIName="L9Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.55};
	float L9Intensity <
		string UIName="L9Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.4};

//Lens10
	float L10Offset <
		string UIName="L10Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {0.91};
	float L10Scale <
		string UIName="L10Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.55};
	float L10Intensity <
		string UIName="L10Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.4};

//Lens11
	float L11Offset <
		string UIName="L11Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {1.76};
	float L11Scale <
		string UIName="L11Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.9};
	float L11Intensity <
		string UIName="L11Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.52};

//Lens12
	float L12Offset <
		string UIName="L12Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {1.79};
	float L12Scale <
		string UIName="L12Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.95};
	float L12Intensity <
		string UIName="L12Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.4};

//Lens13
	float L13Offset <
		string UIName="L13Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {1.84};
	float L13Scale <
		string UIName="L13Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {2.65};
	float L13Intensity <
		string UIName="L13Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens14
	float L14Offset <
		string UIName="L14Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {1.88};
	float L14Scale <
		string UIName="L14Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {2.65};
	float L14Intensity <
		string UIName="L14Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens15
	float L15Offset <
		string UIName="L15Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {1.99};
	float L15Scale <
		string UIName="L15Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {4.45};
	float L15Intensity <
		string UIName="L15Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens16
	float L16Offset <
		string UIName="L16Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {2.0};
	float L16Scale <
		string UIName="L16Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.35};
	float L16Intensity <
		string UIName="L16Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens17
	float L17Offset <
		string UIName="L17Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {2.27};
	float L17Scale <
		string UIName="L17Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.0};
	float L17Intensity <
		string UIName="L17Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens18
	float L18Offset <
		string UIName="L18Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {2.3};
	float L18Scale <
		string UIName="L18Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.78};
	float L18Intensity <
		string UIName="L18Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.94};

//Lens19
	float L19Offset <
		string UIName="L19Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {2.4};
	float L19Scale <
		string UIName="L19Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.69};
	float L19Intensity <
		string UIName="L19Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {1.0};

//Lens20
	float L20Offset <
		string UIName="L20Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {2.55};
	float L20Scale <
		string UIName="L20Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.29};
	float L20Intensity <
		string UIName="L20Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.45};

//Lens21
	float L21Offset <
		string UIName="L21Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {2.59};
	float L21Scale <
		string UIName="L21Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {0.41};
	float L21Intensity <
		string UIName="L21Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.64};

//Lens22
	float L22Offset <
		string UIName="L22Offset";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=4.0;
	> = {3.04};
	float L22Scale <
		string UIName="L22Scale";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=12.0;
	> = {1.05};
	float L22Intensity <
		string UIName="L22Intensity";
		string UIWidget="Spinner";
		float UIMin=0.0;
		float UIMax=2.0;
	> = {0.54};

//++++++++++++++++++++++++++++++++++++++++++++++++
//external parameters, do not modify
//++++++++++++++++++++++++++++++++++++++++++++++++

float4	tempF1; //0,1,2,3
float4	tempF2; //5,6,7,8
float4	tempF3; //9,0
float4	ScreenSize;
float4	Timer;
float	EAdaptiveQualityFactor;
float4	LightParameters;
float	FieldOfView;
texture2D texColor;
texture2D texMask;

sampler2D SamplerColor = sampler_state
{
	Texture   = <texColor>;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};

sampler2D SamplerMask = sampler_state
{
	Texture   = <texMask>;
	MinFilter = LINEAR;
	MagFilter = LINEAR;
	MipFilter = NONE;
	AddressU  = Clamp;
	AddressV  = Clamp;
	SRGBTexture=FALSE;
	MaxMipLevel=0;
	MipMapLodBias=0;
};

struct VS_OUTPUT_POST
{
	float4 vpos  : POSITION;
	float2 txcoord : TEXCOORD0;
};

struct VS_INPUT_POST
{
	float3 pos  : POSITION;
	float2 txcoord : TEXCOORD0;
};

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

VS_OUTPUT_POST VS_Draw(VS_INPUT_POST IN, uniform float offset, uniform float scale)
{
	VS_OUTPUT_POST OUT;

	float4 pos=float4(IN.pos.x,IN.pos.y,IN.pos.z,1.0);
	pos.y*=ScreenSize.z;

	//create own parameters instead of this, including uv offsets
	float2 shift=LightParameters.xy * offset;
	pos.xy=pos.xy * (scale * (ELenzScale * 0.25)) - shift;

	OUT.vpos=pos;
	OUT.txcoord.xy=IN.txcoord.xy;

	return OUT;
}

float4 PS_Draw(VS_OUTPUT_POST IN, float2 vPos : VPOS, uniform float lensintensity) : COLOR
{
	float4 res;
	float2 coord=IN.txcoord.xy;

	//read sun visibility as amount of effect
	float sunmask=tex2D(SamplerMask, float2(0.5, 0.5)).x;
	sunmask=pow(sunmask, ECloudBlend);//more contrast to clouds
	clip(sunmask-0.02);//early exit if too low

	float4 origcolor=tex2D(SamplerColor, coord.xy);
	sunmask*=LightParameters.w * ELenzIntensity;
	res.xyz=origcolor * sunmask;

	float clipper=dot(res.xyz, 0.333);
	clip(clipper-0.0003);//skip draw if black

	res.xyz*=lensintensity;
	res.w=1.0;
	return res;
}

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

technique Draw
{
	pass P0
	{
		VertexShader = compile vs_3_0 VS_Draw((L0Offset - 1.0), (L0Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L0Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P1
	{
		VertexShader = compile vs_3_0 VS_Draw((L1Offset - 1.0), (L1Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L1Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P2
	{
		VertexShader = compile vs_3_0 VS_Draw((L2Offset - 1.0), (L2Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L2Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P3
	{
		VertexShader = compile vs_3_0 VS_Draw((L3Offset - 1.0), (L3Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L3Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P4
	{
		VertexShader = compile vs_3_0 VS_Draw((L4Offset - 1.0), (L4Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L4Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P5
	{
		VertexShader = compile vs_3_0 VS_Draw((L5Offset - 1.0), (L5Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L5Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P6
	{
		VertexShader = compile vs_3_0 VS_Draw((L6Offset - 1.0), (L6Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L6Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P7
	{
		VertexShader = compile vs_3_0 VS_Draw((L7Offset - 1.0), (L7Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L7Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P8
	{
		VertexShader = compile vs_3_0 VS_Draw((L8Offset - 1.0), (L8Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L8Intensity);
		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P9
	{
		VertexShader = compile vs_3_0 VS_Draw((L9Offset - 1.0), (L9Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L9Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P10
	{
		VertexShader = compile vs_3_0 VS_Draw((L10Offset - 1.0), (L10Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L10Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P11
	{
		VertexShader = compile vs_3_0 VS_Draw((L11Offset - 1.0), (L11Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L11Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P12
	{
		VertexShader = compile vs_3_0 VS_Draw((L12Offset - 1.0), (L12Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L12Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P13
	{
		VertexShader = compile vs_3_0 VS_Draw((L13Offset - 1.0), (L13Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L13Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P14
	{
		VertexShader = compile vs_3_0 VS_Draw((L14Offset - 1.0), (L14Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L14Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P15
	{
		VertexShader = compile vs_3_0 VS_Draw((L15Offset - 1.0), (L15Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L15Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P16
	{
		VertexShader = compile vs_3_0 VS_Draw((L16Offset - 1.0), (L16Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L16Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P17
	{
		VertexShader = compile vs_3_0 VS_Draw((L17Offset - 1.0), (L17Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L17Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P18
	{
		VertexShader = compile vs_3_0 VS_Draw((L18Offset - 1.0), (L18Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L18Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P19
	{
		VertexShader = compile vs_3_0 VS_Draw((L19Offset - 1.0), (L19Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L19Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P20
	{
		VertexShader = compile vs_3_0 VS_Draw((L20Offset - 1.0), (L20Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L20Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P21
	{
		VertexShader = compile vs_3_0 VS_Draw((L21Offset - 1.0), (L21Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L21Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}

	pass P22
	{
		VertexShader = compile vs_3_0 VS_Draw((L22Offset - 1.0), (L22Scale*0.1));
		PixelShader  = compile ps_3_0 PS_Draw(L22Intensity);

		AlphaBlendEnable=TRUE;
		SrcBlend=ONE;
		DestBlend=ONE;

		DitherEnable=FALSE;
		ZEnable=FALSE;
		CullMode=NONE;
		ALPHATESTENABLE=FALSE;
		SEPARATEALPHABLENDENABLE=FALSE;
		StencilEnable=FALSE;
		FogEnable=FALSE;
		SRGBWRITEENABLE=FALSE;
	}
}
